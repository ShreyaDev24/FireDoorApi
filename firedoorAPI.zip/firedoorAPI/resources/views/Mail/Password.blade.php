<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>

<body>
<h2>Welcome to the site</h2>
<br/>
<p>Hello {{ $usermname }}, Your OTP is {{ $otp }}.</p>
</body>

</html>
