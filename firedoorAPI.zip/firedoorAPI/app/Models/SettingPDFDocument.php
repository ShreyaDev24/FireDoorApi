<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingPDFDocument extends Model
{
    protected $table = 'settingpdf_document';
}
