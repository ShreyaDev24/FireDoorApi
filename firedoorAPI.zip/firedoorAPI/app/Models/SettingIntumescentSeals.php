<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingIntumescentSeals extends Model
{
    protected $table = 'setting_intumescentseals';
}
