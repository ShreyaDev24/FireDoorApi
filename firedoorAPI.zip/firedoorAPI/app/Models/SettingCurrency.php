<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingCurrency extends Model
{
    protected $table = 'setting_currency';
}
