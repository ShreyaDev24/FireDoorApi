<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BomGeneralLabourCost extends Model
{
    protected $table = 'general_labour_cost';
}