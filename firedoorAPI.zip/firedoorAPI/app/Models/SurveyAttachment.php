<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyAttachment extends Model
{
    protected $table = 'survey_attachment';
}
