<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingIntumescentSeals2 extends Model
{
    protected $table = 'setting_intumescentseals2';
}
