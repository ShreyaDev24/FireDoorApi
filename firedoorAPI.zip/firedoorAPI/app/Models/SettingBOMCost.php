<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SettingBOMCost extends Model
{
    protected $table = 'setting_bomcost';
}
