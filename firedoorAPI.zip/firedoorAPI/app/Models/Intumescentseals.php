<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Intumescentseals extends Model
{
    protected $table = 'intumescentseals2';
}
