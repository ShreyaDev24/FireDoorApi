<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BOMDetails extends Model
{
    protected $table = 'bom_details';
}
