<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanyQuotationCounter extends Model
{
    protected $table = 'company_quotation_counter';
}
