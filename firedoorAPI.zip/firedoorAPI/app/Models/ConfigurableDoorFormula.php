<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConfigurableDoorFormula extends Model
{
    protected $table = 'configurable_door_formula';
}
