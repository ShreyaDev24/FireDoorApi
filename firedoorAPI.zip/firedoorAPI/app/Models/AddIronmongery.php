<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AddIronmongery extends Model
{
    protected $table = 'add_ironmongery';  
}