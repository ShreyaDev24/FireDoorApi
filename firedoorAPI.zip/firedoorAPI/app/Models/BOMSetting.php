<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BOMSetting extends Model
{
    protected $table = 'bom_setting';
}
