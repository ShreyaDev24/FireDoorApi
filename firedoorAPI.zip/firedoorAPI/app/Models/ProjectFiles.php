<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectFiles extends Model
{
    
    protected $table = 'projectfiles';
  
    
}
