<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectedGeneralLabourCost extends Model
{
    protected $table = 'selected_generallabourcost';
}