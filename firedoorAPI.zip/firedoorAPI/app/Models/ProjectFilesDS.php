<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectFilesDS extends Model
{
    
    protected $table = 'projectfilesds';
  
    
}
