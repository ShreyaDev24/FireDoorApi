<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyInfo extends Model
{
    protected $table = 'survey_info';
}
