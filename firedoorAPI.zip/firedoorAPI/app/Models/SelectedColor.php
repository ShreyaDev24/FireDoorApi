<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectedColor extends Model
{
    protected $table = 'selected_color';
}
