<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectedDoordimension extends Model
{
    protected $table = 'selected_doordimension';
}
