<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyChangerequest extends Model
{
    protected $table = 'survey_changerequest';
}
