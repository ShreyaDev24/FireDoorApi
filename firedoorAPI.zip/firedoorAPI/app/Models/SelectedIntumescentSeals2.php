<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectedIntumescentSeals2 extends Model
{
    protected $table = 'selected_intumescentseals2';
}
