<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SelectedIronmongery extends Model
{
    protected $table = 'selected_ironmongery';
}
