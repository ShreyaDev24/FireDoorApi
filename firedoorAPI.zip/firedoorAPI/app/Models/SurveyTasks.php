<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurveyTasks extends Model
{
    protected $table = 'survey_tasks';
}
