<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuotationSiteDeliveryAddress extends Model
{
    protected $table = 'quotation_sitedeliveryaddress';
}
